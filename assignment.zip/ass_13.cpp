#include<stdio.h>
#include<string.h>
int main()
{
    char s[100], result;
  	int i, l;
  	int max = -1;

  	int freq[256] = {0};

  	printf("\nEnter any String :  ");
  	gets(s);
  	l = strlen(s);

  	for(i = 0; i < l; i++)
  	{
  		freq[s[i]]++;
	}

  	for(i = 0; i < l; i++)
  	{
		if(max < freq[s[i]])
		{
			max = freq[s[i]];
			result = s[i];
		}
	}
	printf("\n The Maximum Occurring :%c ", result);
    return 0;
}

#include<stdio.h>
#include<string.h>
int main()
{
     int i;
        char s[100];
        int u=0,lw=0,sp=0;
        printf("the string:");
        scanf("%[^\n]%*c",s);
        int l=strlen(s);
        for(i=0;i<l;i++)
        {
                if(s[i]>='A'&&s[i]<='Z')
                {
                        u++;
                }
                else if(s[i]>='a'&&s[i]<='z')
                {
                        lw++;
                }
                else if((s[i]>='!'&&s[i]<='/')||(s[i]>=':'&&s[i]<='@')||(s[i]>='['&&s[i]<='`')||(s[i]>='{'&&s[i]<='~'))
                {
                        sp++;
                }
        }
        printf("the upper case count is:%d\n",u);
        printf("the lower case count is:%d\n",lw);
        printf("the special characters count is:%d\n",sp);
    return 0;
}

#include<stdio.h>
#include<string.h>
int main()
{
      char s[100];
    printf("the string:");
    gets(s);
    int i,l=strlen(s);
    for(i=0;i<l;i++)
    {
        if(s[i]=='a'||s[i]=='A'||s[i]=='O'||s[i]=='o'||s[i]=='E'||s[i]=='e'||s[i]=='I'||s[i]=='i'||s[i]=='u'||s[i]=='U')
        {
                s[i]='*';
        }
        else if(s[i]!=' ')
        {
                s[i]='#';
        }
    }
    printf("the resultant string: %s",s);
    return 0;
}

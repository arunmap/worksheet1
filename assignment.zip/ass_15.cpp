#include<stdio.h>
#include<string.h>
int main()
{
    int i,j=0;
    char s[100];
    char a[100];
    printf("the string:");
    gets(s);
    int l1=strlen(s),t=0;
    printf("the substring to be searched:");
    gets(a);
    int l2=strlen(a);
    for(i=0;i<l1;i++)
    {
        if(s[i]==a[j])
        {
            t++;
            j++;
            if(t==l2)
            break;
        }
        else
        {
            j=0;
            t=0;
        }
    }
    if(t==l2)
    {
        printf("the word is present-%s\n",a);
    }
    else
    printf("the word is not present-%s\n",a);

    return 0;
}

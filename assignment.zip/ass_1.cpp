#include<stdio.h>
#include<string.h>
int main()
{
    int i;
        char s[100];
        printf("enter the string\n");
        scanf("%[^\n]%s",s);
        int l=strlen(s);
        for(i=0;i<l;i++)
        {
                printf("%c\n",s[i]);
        }
    return 0;
}

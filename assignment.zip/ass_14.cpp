#include<stdio.h>
#include<string.h>
int main()
{
    int i,j;
    char s[100];
    printf("the string:");
    gets(s);
    int l=strlen(s);
    char a;
    printf("the character to be removed\n");
    scanf("%c",&a);
    int t=0;
    for(i=0;i<l;i++)
    {
        if(s[i]==a)
        t++;
    }
    if(t==0)
    printf("invalid");
    else
    {
        for(i=0;i<l-1;i++)
        {
            if(s[i]==a)
            {
                for(j=i+1;j<l;j++)
                {
                    s[j-1]=s[j];
                }
                s[l-1]='\0';
            }
        }
    }
    printf("the result string : %s",s);
    return 0;
}

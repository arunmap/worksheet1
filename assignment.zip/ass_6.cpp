#include<stdio.h>
#include<string.h>
int main()
{
    int i;
    char s[100];
    printf("the string:");
    gets(s);
    printf("the reversed string is: %s\n",strrev(s));
    return 0;
}

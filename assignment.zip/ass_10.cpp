#include<stdio.h>
#include<string.h>
int main()
{
     int i,j;
    char s[100];
    printf("the string:");
    gets(s);
    int l=strlen(s);
    for(i=0;i<l;i++)
    {
        for(j=0;j<l-i;j++)
        {
            printf("%c",s[j]);
        }
        printf("\n");
    }
    return 0;
}

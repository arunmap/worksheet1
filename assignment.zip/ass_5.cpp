#include<stdio.h>
#include<string.h>
int main()
{
   int i;
    char s[100];
    printf("the string:");
    gets(s);
    int l=strlen(s);
    for(i=0;i<l;i++)
    {
        if(s[i]>='A'&&s[i]<='Z')
        s[i]=s[i]+32;
        else if(s[i]>='a'&&s[i]<='z')
        s[i]=s[i]-32;
    }
    printf("the result string is: %s\n",s);
    return 0;
}

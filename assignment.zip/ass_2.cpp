#include<stdio.h>
#include<string.h>
int main()
{
      int i;
        char s[100];
        printf("the string :");
        scanf("%[^\n]%*c",s);
        int l=strlen(s),j=0,k=0;
        char v[l],c[l];
        for(i=0;i<l;i++)
        {
                if(s[i]=='a'||s[i]=='A'||s[i]=='O'||s[i]=='o'||s[i]=='E'||s[i]=='e'||s[i]=='I'||s[i]=='i'||s[i]=='u'||s[i]=='U')
                {
                        v[j]=s[i];
                        j++;
                }
                else if(s[i]!=' ')
                {
                        c[k]=s[i];
                        k++;
                }
        }
        printf("the vowels are:\n%c\n",v[0]);
        for(i=1;i<j;i++)
        {
                if(v[i]!=v[0])
		 printf("%c\n",v[i]);
        }
        printf("the consonants are:\n%c\n",c[0]);
        for(i=1;i<k;i++)
        {
                if(c[i]!=c[0])
                {
                        printf("%c\n",c[i]);
                }
        }
    return 0;
}

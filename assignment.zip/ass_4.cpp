#include<stdio.h>
#include<string.h>
int main()
{
        int i;
    char s[100];
    printf("the string:");
    gets(s);
    printf("the string in lower cases is: %s\n",strlwr(s));
    printf("the string in upper case is: %s\n",strupr(s));

    return 0;
}

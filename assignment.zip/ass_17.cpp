#include<stdio.h>
#include<string.h>
int main()
{
    char s[100],a[100];
    int i=0,j=0,k;
    printf("Enter the string\n");
    gets(s);
    printf("Enter the word to be removed\n");
    gets(a);
    int l=strlen(s);
    for(i=0;i<l;i++)
    {
        while(s[i]==a[j]&&a[j]!='\0')
        {
            for(k=i;s[k]!='\0';k++)
            {
                s[k]=s[k+1];
            }
            j++;
        }
    }
printf("string after the reverse is\n\n%s",s);
return 0;
}

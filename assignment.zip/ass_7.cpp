#include<stdio.h>
#include<string.h>
int main()
{
     int i;
    char s[100];
    printf("the string:");
    gets(s);
    printf("the character(occurance to be checked):");
    char n;
    scanf("%c",&n);
    int l=strlen(s),k=0;
    for(i=0;i<l;i++)
    {
        if(s[i]==n)
        k++;
    }
    printf("the occurance of %c is %d\n",n,k);
    return 0;
}

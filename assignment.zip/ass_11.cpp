#include<stdio.h>
#include<string.h>
int main()
{
     int i,j;
    char s[100];
    printf("the string:");
    gets(s);
    int l=strlen(s);
    int t=0,max=0;
    char a;
    for(i=0;i<l-1;i++)
    {
        t=0;
        for(j=i+1;j<l;j++)
        {
            if(s[i]==s[j])
            t++;
        }
        if(t>max)
        {
            max=t;
            a=s[i];
        }
    }
    printf("the highest occured : %c - %d times\n",a,max+1);
    return 0;
}

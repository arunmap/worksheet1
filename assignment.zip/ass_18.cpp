#include<stdio.h>
#include<string.h>
int main()
{
    int i,j,k=0;
    char s[100],a[100],w[100];
    printf("enter the string :");
    gets(s);
    int l1=strlen(s);
    printf("enter the second string :");
    gets(a);
    int l2=strlen(a);
    for (i = 0; s[i]!= '\0'; i++)
    {
        for (j = 0; a[j] != '\0'; j++)
        {
            if (s[i] == a[j])
            {
                continue;
            }
            else
            {
                w[k] = a[j];
                k ++;
            }
        }
        w[k] = '\0';
        strcpy(a,w);
        k = 0;
    }

    printf ("On removing characters from second string : %s\n",w);
    return 0;
}

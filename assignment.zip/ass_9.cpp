#include<stdio.h>
#include<string.h>
int main()
{
      int i,j;
    char s[100];
    printf("the string:");
    gets(s);
    int l=strlen(s);
    for(i=0;i<l-1;i++)
    {
        for(j=0;j<i+1;j++)
        printf("%c",s[j]);
        printf("\n");
    }
    printf("%s",s);
    return 0;
}
